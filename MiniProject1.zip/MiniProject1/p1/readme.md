Instructor solution code for P1 Search project
